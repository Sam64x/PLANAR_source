clc; close all; clear all %#ok<CLALL>
n = 100; m = 100; h = 1/n; T = 1/m; h2= h^2; g = T/h2;
U =zeros(n+1,m+1); x = zeros(1,n+1); t = zeros(1,m+1);
C0 = g/(1+2*g); C1 = 1/(1+2*g);

alpha = 0.8; N = 9;
K = zeros(1, n+1); K1 = zeros(1, N);
tau = zeros(1, n+1);
ult = zeros(1, n+1); ux0t = zeros(1, n+1); gt = zeros(1, n+1);

% Шум
delta = 0.03;


% Построение сетки
for i = 1 : n+1
    t(i) = h * (i-1);
    tau(i) = h * (i-1);
end

% ux(0, t)
for i = 1 : n+1
    ux0t(i) = exp(t(i)) - 1 + delta*(2*rand(1) - 1); %a=0.8;b=0.03;N=9;n=100
    % ux0t(i) = t(i) * exp(t(i)) + DELTA(i); %a=0.217;b=0.03;N=7;n=80
end

% u(l,t)
for i = 1 : n+1
    ult(i) = exp(t(i)) - 1;
    % ult(i) = exp(t(i)) * t(i) + exp(t(i)) - 1; 
end

% Аппроксимация ядра
for i = 1 : n+1
    for j = 1 : i
        K_sum = 0;
        for c = 1:N
            K_sum = K_sum + (-1).^(c+1)*pi.^2*c^2*exp(-1*(c.^2)*(pi.^2)*(t(i)-tau(j)));
        end
        K(i, j) = K_sum;
    end
end


A = zeros(n+1, 1); B = zeros(n+1, 1);
% Построение матрицы свободных членов
for i = 1 : n+1
    for j = 1 : i
        A(i, j) =  (2*K(i, j) + alpha);
    end
end

% Построение матрицы коэффициентов
for i = 1 : n+1
    B(i) = ux0t(i);
end


% Формирование решения СЛАУ
ULT = (A \ B)*1000;


% Формирование значений функции погрешности
DT = zeros(1, n+1);
for i = 1 : n+1
    DT(i) = abs(ULT(i) - ult(i));
end

%Формирование графика погрешности
figure;
plot(t, DT);
title("Функция погрешности \Delta; \delta = " + delta * 100 + "%")
grid on
ax = gca;
ax.GridAlpha = 0.4;

% Построение графиков численного и точного решения ОЗТ
figure
plot(t, ult, t, ULT);
ylabel("Температура");
xlabel("Время");
lgd = legend("$\xi(t)$","$\hat{\xi}(t)$",'Location','southeast');
lgd.Title.String = "$\alpha=  $" + alpha + "; N=" + N + "; n=" + n;
lgd.Title.FontSize = 10;
set(lgd,'FontSize',14,'Interpreter','latex');
grid on;
ax = gca;
ax.GridAlpha = 0.4;
title("Графики численного и точного решений u(l,t)")

disp(max(DT))

% Построение сетки
for i = 1 : n+1
    x(i) = (i-1)*h;
end

for j = 1: m+1
    t(j) = (j-1)*T;
end

% Тестовая функция u0(x, t) 
U0 = zeros(n+1, m+1);
for i = 1 : n+1
    for j = 1 : n+1
        U0(i,j) = x(i)*(exp(t(j))) - x(i);
    end
end

% Формирование и зашумление значений во внешних узлах сетки
for i = 1 : n+1
    U(i, 1) = U0(i, 1) + delta*(2*rand(1) - 1) * U0(i, j);
end
for j = 1 : m+1
    U(1, j) = U0(1, j) + delta*(2*rand(1) - 1) * U0(i, j);
    U(n+1, j) = ULT(j);
end

% Построение матрицы коэффициентов
C = zeros(n-2);
k = 0;
for i = 1 : n-1
    if (i == 1)
        for j = 1 : 2
            if j == 1
                C(i, j) = 1;
            else
                C(i, j) = -1 * C0;
            end
        end
    elseif (i == n-1)
        for j = n-2 : n-1
            if j == n-2
                C(i, j) = -1 * C0;
            else
                C(i, j) = 1;
            end
        end
    else
       k = k + 1;
       C(i, k) = -1 * C0;
       C(i, k+1) = 1;
       C(i, k+2) = -1 * C0;
    end
end

% Матрица свободных членов
p = 1;
while(p <= m)
    B = zeros(n-2, 1);
    for i = 2 : n
            if (i == 2)
                B(i-1) = C1*U(i,p) + C0*U(i-1,p+1);
            elseif (i==n)
                B(i-1) = C1*U(i, p) + C0*U(i+1,p+1);
            else
                B(i-1) = C1*U(i, p);
            end
    end
    ULT = C \ B;
    p = p + 1;
    for i = 2 : n
            U(i, p) = ULT(i-1);
    end
end

% Построение графика приближенного решения
figure
surf(t,x,U);
title(['Приближенное решение \delta = ', num2str(delta*100), '%']);
ylabel('X')
xlabel('Время') 
zlabel('Значение температуры')
max_D = abs(U0(1,1) - U(1,1));
percent = 0;
% Построение графиков погрешности
D = zeros(n+1, m+1);
for i = 1 : n+1
    for j = 1 : m+1
        D(i,j) = abs(U0(i,j) - U(i,j));
    end
end

figure
surf(D);
title(['Функция температурных погрешностей \delta = ', num2str(delta*100), '%']);
ylabel('X')
xlabel('Время') 
zlabel('Значение температуры')

% Построение графика точной функций
figure
surf(t,x,U0);
title('Точное решение');
ylabel('X')
xlabel('Время') 
zlabel('Значение температуры')
disp(max(max(D)));
