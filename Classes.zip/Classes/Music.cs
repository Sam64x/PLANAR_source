﻿using System.Collections;
using System.Configuration;
using System.Xml.Serialization;

namespace Classes
{
    interface ILogger<T>
    {
        event Action<TextWriter, string>? OnLog;
        void Log(string Message);
    }

    public interface ISerializer
    {
        void Serialize(PlayList<Track> playlist, string path);

        PlayList<Track> Deserialize(string path);
    }

    class SerializerXML : ISerializer
    {
        private readonly XmlSerializer formatter = new(typeof(PlayList<Track>));


        public PlayList<Track> Deserialize(string path)
        {
            using var fs = new FileStream(path, FileMode.Open);
            Console.WriteLine("Playlist deserialized from XML file.");
            if (formatter.Deserialize(fs) is PlayList<Track> playlist)
                return playlist;
            else
                throw new Exception("Playlist doesnt exist");
        }

        public void Serialize(PlayList<Track> playlist, string path)
        {
            using (var fs = new FileStream(path, FileMode.Create))
            {
                formatter.Serialize(fs, playlist);
            }
            Console.WriteLine("Playlist saved to XML file.");
        }
    }

    public class Logger<T> : ILogger<T>
    {
        public string? Path { get; set; }
        public Logger(string ?path)
        {
            Path = path;
        }

        public Logger() => Path = null;

        public event Action<TextWriter, string>? OnLog;

        public void Log(string? Message)
        {
            if (OnLog != null)
            {
                TextWriter? writer;
                if (Path == null)
                {
                    writer = Console.Out;
                }
                else
                {
                    writer = File.AppendText(Path);
                }

                var line = typeof(T).ToString() + ": " + Message;
                OnLog(writer, line);
                writer.Close();
            }
        }
    }

    [XmlInclude(typeof(Track))]
    [XmlInclude(typeof(Genre))]
    [XmlInclude(typeof(Author))]
    [XmlInclude(typeof(Album))]
    [XmlInclude(typeof(FreeTrack))]
    [XmlInclude(typeof(PremiumTrack))]
    public class PlayList<T> : IEnumerable<T> where T : Track
    {
        public List<T> A { get; set; } = new();
        public Logger<Track>? logger;

        public void Add(T data)
        {
            A.Add(data);
        }

        public void Add(T data, Logger<Track>? logger = null)
        {
            A.Add(data);
            this.logger = logger;
            if (logger != null)
                logger.Log("Track added");
        }

        public static void LaunchSerializer(ISerializer serializer, string path, PlayList<Track> playlist)
        {
            serializer.Serialize(playlist, path);
            PlayList<Track> newPlayList = serializer.Deserialize(path);
            newPlayList.Print();
        }

        public int Count()
        {
            return A.Count;
        }

        public void Sort(Func<T, T, int> value)
        {
            A.Sort((x, y) => value(x, y));
        }

        public void Show_By_Type(string? Type)
        {
            Console.Clear();
            HashSet<string> set = new();

            if (Type == "Genre")
            {
                foreach (var item in A)
                {
                    set.Add(item.Genre.Genre_name);
                }
            }
            if (Type == "Author")
            {

                foreach (var item in A)
                {
                    set.Add(item.Author.Author_name);
                }
            }
            if (Type == "Album")
            {
                foreach (var item in A)
                {
                    set.Add(item.Album.Album_name);
                }
            }

            while (true)
            {
                Console.Clear();
                int i = 0;
                foreach (var item in set)
                {
                    i++;
                    Console.WriteLine(i + ")" + item.ToString());
                }
                Console.Write($"\nInput the number of your preferred {Type}: ");
                int n = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine();
                i = 0;
                foreach (var type in set)
                {
                    i++;
                    if (i == n)
                    {
                        i = 0;
                        foreach (var item in A)
                        {
                            if (Type == "Album")
                            {
                                if (item.Album.Album_name == type.ToString())
                                {
                                    i++;
                                    item.Print(i);
                                }
                            }

                            if (Type == "Author")
                            {
                                if (item.Author.Author_name == type.ToString())
                                {
                                    i++;
                                    item.Print(i);
                                }
                            }


                            if (Type == "Genre")
                            {
                                if (item.Genre.Genre_name == type.ToString())
                                {
                                    i++;
                                    item.Print(i);
                                }
                            }
                        }
                        break;
                    }
                }
                Console.WriteLine($"\nPress Enter to choose {Type} again");
                Console.WriteLine("Press Any other button to return to menu");
                if (Console.ReadKey().Key != ConsoleKey.Enter)
                {
                    break;
                }
            }
        }

        public void Print()
        {
            int i = 0;
            foreach (var item in A)
            {
                i++;
                item.Print(i);
            }
        }

        public IEnumerator<T> GetEnumerator()
        {
            return A.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return A.GetEnumerator();
        }
    }

    public class Genre
    {
        public string Genre_name = "";

        public Genre() { }

        public Genre(string genre_name)
        {
            Genre_name = genre_name;
        }
    }

    public class Author
    {

        public string Author_name = "";
        public Author() { }

        public Author(string author_name)
        {
            Author_name = author_name;
        }
    }

    public class Album
    {
        public string Album_name = "";

        public Album() { }

        public Album(string album_name)
        {
            Album_name = album_name;
        }
    }

    public class FreeTrack : Track
    {
        public FreeTrack() : base() { }

        public FreeTrack(string author, string track, string album, string genre) : base(author, track, album, genre)
        {

        }

        public override void Print(int i)
        {
            base.Print(i);
            Console.Write("\n");
        }

    }

    public class PremiumTrack : Track
    {
        public int Price;

        public PremiumTrack() : base() { }

        public PremiumTrack(string author, string track, string album, string genre, int price) : base(author, track, album, genre)
        {
            Price = price;
        }
        public override void Print(int i)
        {
            base.Print(i);
            Console.Write(" - Price: " + Price + "\n");
        }
    }

    public abstract class Track
    {
        public string Track_name = "";
        public Author Author = new();
        public Album Album = new();
        public Genre Genre = new();

        public Track() { }

        public Track(string author, string track, string album, string genre)
        {
            Author = new Author(author);
            Track_name = track;
            Album = new Album(album);
            Genre = new Genre(genre);
        }

        public virtual void Print(int i)
        {
            if (Track_name != null)
            {
                Console.Write($"{i}){Track_name} - ");
            }
            if (Author != null)
            {
                Console.Write(Author.Author_name + " -");
            }
            if (Album != null)
            {
                Console.Write(Album.Album_name + " -");
            }
            if (Genre != null)
            {
                Console.Write(Genre.Genre_name);
            }
        }
    }

    class Music
    {
        static void Main()
        {
            ConsoleKeyInfo flag, flag1;
            string? log_path = ConfigurationManager.AppSettings["log_path"];
            Logger<Track> logger = new(log_path);
            logger.OnLog += Logger_OnLog;

            StreamReader sr;
            PlayList<FreeTrack> free_playlist = new();
            sr = new StreamReader("FreeTracks.txt");
            var text = "";
            while ((text = sr.ReadLine()) != null)
            {
                string[] lines = text.Split(',');
                free_playlist.Add(new FreeTrack(lines[0], lines[1], lines[2], lines[3]), logger);
            }
            sr.Close();
            PlayList<PremiumTrack> premium_playlist = new();
            sr = new StreamReader("PremiumTracks.txt");
            text = "";
            while ((text = sr.ReadLine()) != null)
            {
                string[] lines = text.Split(',');
                premium_playlist.Add(new PremiumTrack(lines[0], lines[1], lines[2], lines[3], Int32.Parse(lines[4])), logger);
            }
            sr.Close();

            PlayList<Track> playlist = new();
            foreach (var item in free_playlist)
                playlist.Add(item);
            foreach (var item in premium_playlist)
                playlist.Add(item);

            // Console Menu
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Press F1 to show Playlist");
                Console.WriteLine("Press F2 to show Playlist by Genre");
                Console.WriteLine("Press F3 to show Playlist by Author");
                Console.WriteLine("Press F4 to show Playlist by Album");
                Console.WriteLine("Press F5 to show Premium Playlist");
                Console.WriteLine("Press F6 to show Logs");
                Console.WriteLine("Press F7 to launch serializer");
                Console.WriteLine("Press Enter to exit");
                flag = Console.ReadKey();

                if (flag.Key == ConsoleKey.Enter)
                {
                    break;
                }

                if (flag.Key == ConsoleKey.F7)
                {
                    Console.Clear();
                    string ?serialize_path = ConfigurationManager.AppSettings["serialize_path"];
                    if (serialize_path != null)
                    {
                        var xmlSerializer = new SerializerXML();
                        PlayList<Track>.LaunchSerializer(xmlSerializer, serialize_path, playlist);
                        Console.WriteLine("\nPress Any button to return to menu");
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("The path for serializing is not specified");
                        Console.WriteLine("Press Any button to return to menu");
                        Console.ReadKey();
                    }
                }

                if (flag.Key == ConsoleKey.F6) // Show Logs
                {
                    while (true)
                    {
                        Console.Clear();
                        if (log_path != null)
                        {
                            if (File.Exists(log_path))
                            {
                                sr = new StreamReader(log_path);
                            }
                            else
                            {
                                Console.WriteLine("Log file doesn't exist");
                                Console.WriteLine("Press Any button to return to menu");
                                Console.ReadKey();
                                break;
                            }
                        }    

                        else
                        {
                            Console.WriteLine("Log file is not specified");
                            Console.WriteLine("Press Any button to return to menu");
                            Console.ReadKey();
                            break;
                        }
                        text = sr.ReadLine();
                        if (text == null)
                        {
                            Console.WriteLine("Log file is empty");
                            Console.WriteLine("Press Any button to return to menu");
                            Console.ReadKey();
                            break;
                        }
                        while (text != null)
                        {
                            Console.WriteLine(text);
                            text = sr.ReadLine();
                        }

                        sr.Close();

                        Console.WriteLine("\nPress F1 to clear Log file");
                        Console.WriteLine("Press F2 to delete Log file");
                        Console.WriteLine("Press Any other button to return to menu");
                        flag1 = Console.ReadKey();
                        if (flag1.Key == ConsoleKey.F1)
                        {
                            File.WriteAllText(log_path, string.Empty);
                            break;
                        }
                        else if (flag1.Key == ConsoleKey.F2)
                        {
                            File.Delete(log_path);
                            break;
                        }
                        else
                        {
                            break;
                        }
                    }
                }

                if (flag.Key == ConsoleKey.F5) // Show Full Premium Playlist
                {
                    while (true)
                    {
                        Console.Clear();
                        int i = 0;
                        foreach (var item in premium_playlist)
                        {
                            i++;
                            item.Print(i);
                        }
                        Console.WriteLine("\nPress F1 to sort price by ascending");
                        Console.WriteLine("Press F2 to sort price by descending");
                        Console.WriteLine("Press Any other button to return to menu");
                        flag1 = Console.ReadKey();
                        if (flag1.Key == ConsoleKey.F1)
                        {
                            premium_playlist.Sort(delegate (PremiumTrack t1, PremiumTrack t2) { return (t1.Price.CompareTo(t2.Price)); });
                        }
                        else if (flag1.Key == ConsoleKey.F2)
                        {
                            premium_playlist.Sort(delegate (PremiumTrack t1, PremiumTrack t2) { return (t2.Price.CompareTo(t1.Price)); });
                        }
                        else
                        {
                            break;
                        }
                    }
                }

                if (flag.Key == ConsoleKey.F4) // Show Playlist by Album
                {
                    playlist.Show_By_Type("Album");
                }

                if (flag.Key == ConsoleKey.F3) // Show Playlist by Author
                {
                    playlist.Show_By_Type("Author");
                }

                if (flag.Key == ConsoleKey.F2) // Show Playlist by Genre
                {
                    playlist.Show_By_Type("Genre");
                }

                if (flag.Key == ConsoleKey.F1) // Show Full Playlist
                {
                    Console.Clear();
                    playlist.Print();
                    Console.WriteLine("\nPress Any button to return to menu");
                    Console.ReadKey();
                }
            }
        }
        private static void Logger_OnLog(TextWriter writer, string? text)
        {
            var time = DateTime.Now.ToString(" dd/MM/yyyy HH:mm:ss");
            writer.WriteLine(time + " " + text);
        }
    }
}
