﻿class OS4
{
    static int supplier_semaphore = 10;
    static int consumer_semaphore = 0;
    static ConsoleKeyInfo flag;
    static int supplier_pause_time = 3000;
    static int consumer_pause_time = 500;
    static List<int> buffer = new();
    static Random random = new();
    static Thread supplier_thread = new(Supplier);
    static Thread consumer_thread = new(Consumer);
    static List<int> Buffer { get => buffer; set => buffer = value; }
    static Random Random { get => random; set => random = value; }
    public static Thread Consumer_thread { get => consumer_thread; set => consumer_thread = value; }
    public static Thread Supplier_thread { get => supplier_thread; set => supplier_thread = value; }

    static void Main()
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine("Thread simulation \"Supplier - Consumer:");
            Console.WriteLine("FAQ: \nPress F1 - to start thread \nAfter the start:");
            Console.WriteLine("Press F2 - to increase supplier speed");
            Console.WriteLine("Press F3 - to increase consumer speed");
            Console.WriteLine("Press F4 - to balance speed");
            Console.WriteLine("Press F5 - to interrupt thread");
            Console.WriteLine("Press F6 - to stop thread");
            flag = Console.ReadKey();
            if (flag.Key == ConsoleKey.F1)
            {
                Consumer_thread.Start();
                Supplier_thread.Start();
                Consumer_thread.Join();
                Supplier_thread.Join();
            }
        }
    }

    static void Write()
    {
        Buffer.Insert(0, Random.Next(0, 10));
    }

    static void Read()
    {
        Console.Clear();
        Console.WriteLine($"[{string.Join(", ", Buffer)}]\n {Buffer.Count}");
        Buffer.RemoveAt(0);
    }

    static void Speed_Up_Supplier()
    {
        supplier_pause_time = 500;
        consumer_pause_time = 1000;
    }

    static void Balance_Speed()
    {
        supplier_pause_time = 1000;
        consumer_pause_time = 1000;
    }

    static void Speed_Up_Consumer()
    {
        supplier_pause_time = 1000;
        consumer_pause_time = 500;
    }

    static void Interrupt()
    {
        Supplier_thread.Interrupt();
        Console.WriteLine("Thread is interrupted\nPress F5 to awoke him");
        while (true)
        {
            if (Console.ReadKey().Key == ConsoleKey.F5)
            {
                try
                {
                    Thread.Sleep(supplier_pause_time);
                }
                catch (ThreadInterruptedException)
                {
                }
                break;
            }
        }
    }

    static void Supplier()
    {
        while (true)
        {
            if (supplier_semaphore > 0)
            {
                Write();
                consumer_semaphore += 1;
                supplier_semaphore -= 1;
                Thread.Sleep(supplier_pause_time);
                if (Console.KeyAvailable == true)
                {
                    flag = Console.ReadKey(true);
                    if (flag.Key == ConsoleKey.F2)
                    {
                        Speed_Up_Supplier();
                    }
                    if (flag.Key == ConsoleKey.F3)
                    {
                        Speed_Up_Consumer();
                    }
                    if (flag.Key == ConsoleKey.F4)
                    {
                        Balance_Speed();
                    }
                    if (flag.Key == ConsoleKey.F5)
                    {
                        Interrupt();
                    }
                    if (flag.Key == ConsoleKey.F6)
                    {
                        Environment.Exit(1);
                    }
                }
            }
        }
    }

    static void Consumer()
    {
        while (true)
        {
            if (consumer_semaphore > 0)
            {
                Read();
                consumer_semaphore -= 1;
                supplier_semaphore += 1;
                Thread.Sleep(consumer_pause_time);
            }
        }
    }
}