﻿#include <windows.h>
#include <stdio.h>
#include <tchar.h>


void Fill(int* memory_block, size_t block_length) 
{
    for (int i = 0; i < block_length; i++) 
    {
        memory_block[i] = i;
    }
}

void Print(int* memory_block, size_t block_length) 
{
    printf("[");
    for (int i = 0; i < block_length - 1; i++) 
    {
        printf("%d, ", memory_block[i]);
    }
    printf("%d]", memory_block[block_length-1]);
}

int main(void)
{
    int len1, len2;
    printf("Input size of the first heap: ");
    scanf_s("%d", &len1);
    printf("Input size of second heap: ");
    scanf_s("%d", &len2);

    size_t size_1 = len1 * sizeof(int);
    size_t size_2 = len2 * sizeof(int);
    
    int* Memory_Block_1 = (int*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, size_1); // Выделяем блок памяти из кучи по умолчанию.
    // HeapAlloc - Функция, которая выделяет блок памяти из кучи.
    // GetProcessHeap  - функция которая извлекает дескриптор из кучи по умолчанию
    // HEAP_ZERO_MEMORY - флаг, который устанавливает содержимое выделяемой памяти в 0
    Fill(Memory_Block_1, len1);
    printf("First heap:\n");
    Print(Memory_Block_1, len1);

    HANDLE second_heap = HeapCreate(0, HEAP_GENERATE_EXCEPTIONS, 0); // Создание дополнительно выделенной кучи
    // HANDLE - тип (указатель на void) (дескриптор, предназначенный для описания различных объектов)
    // HeapCreate - функция, которая создаёт дополнительную кучу
    // HEAP_GENERATE_EXCEPTIONS в случае ошибки при распределении памяти вместо возврата значения NULL генерируется исключение, которое может быть обработано
    if (second_heap != NULL)
    {
        int* Memory_Block_2 = (int*)HeapAlloc(second_heap, 0, size_2);
        Fill(Memory_Block_2, len2);
        printf("\nSecond heap:\n");
        Print(Memory_Block_2, len2);
        HeapFree(GetProcessHeap(), 0, Memory_Block_1);
        HeapFree(second_heap, 0, Memory_Block_2);
    }
}