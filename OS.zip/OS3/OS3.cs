﻿using System.Text;

namespace OS3
{
    class FCFS
    {
        public static void FindWaitingTime(int[] processes, int n, int[] bt, int[] wt)
        {
            wt[0] = 0;

            for (int i = 1; i < n; i++)
            {
                wt[i] = bt[i - 1] + wt[i - 1];
            }
        }

        public static void FindTurnAroundTime(int[] processes, int n, int[] bt, int[] wt, int[] tat)
        {
            for (int i = 0; i < n; i++)
            {
                tat[i] = bt[i] + wt[i];
            }
        }

        public static void Start_Planning(int[] processes, int n, int[] bt)
        {
            int[] wt = new int[n];
            int[] tat = new int[n];
            int total_wt = 0, total_tat = 0;

            FindWaitingTime(processes, n, bt, wt);

            FindTurnAroundTime(processes, n, bt, wt, tat);

            Console.WriteLine("\nFCFS Schreduling:\n");
            Console.WriteLine(string.Concat(Enumerable.Repeat("-", 58)));
            Console.WriteLine("| Process | Burst time | Waiting time | Turn around time |");
            Console.WriteLine(string.Concat(Enumerable.Repeat("-", 58)));

            for (int i = 0; i < n; i++)
            {
                total_wt += wt[i];
                total_tat += tat[i];
                Console.WriteLine(String.Format("|{1,5}{0,4}|{2,6}{0,6}|{3,8}{0,6}|{4,10}{0,8}|", "", (i + 1), bt[i], wt[i], tat[i]));
            }
            Console.WriteLine(string.Concat(Enumerable.Repeat("-", 58)));
        }
    }


    class RR
    {
        public static void FindWaitingTime(int[] processes, int n, int[] bt, int[] wt, int quantum)
        {
            int[] rem_bt = new int[n];

            for (int i = 0; i < n; i++)
                rem_bt[i] = bt[i];
            int t = 0;
            while (true)
            {
                bool done = true;
                for (int i = 0; i < n; i++)
                {
                    if (rem_bt[i] > 0)
                    {
                        done = false;

                        if (rem_bt[i] > quantum)
                        {
                            t += quantum;
                            rem_bt[i] -= quantum;
                        }
                        else
                        {

                            t += rem_bt[i];
                            wt[i] = t - bt[i];
                            rem_bt[i] = 0;
                        }
                    }
                }
                if (done == true)
                    break;
            }
        }

        public static void FindTurnAroundTime(int[] processes, int n, int[] bt, int[] wt, int[] tat)
        {
            for (int i = 0; i < n; i++)
                tat[i] = bt[i] + wt[i];
        }

        public static void Start_Planning(int[] processes, int n, int[] bt, int quantum)
        {
            int[] wt = new int[n];
            int[] tat = new int[n];
            int total_wt = 0, total_tat = 0;

            FindWaitingTime(processes, n, bt, wt, quantum);

            FindTurnAroundTime(processes, n, bt, wt, tat);

            Console.WriteLine("\nRR Schreduling:\n");
            Console.WriteLine(string.Concat(Enumerable.Repeat("-", 58)));
            Console.WriteLine("| Process | Burst time | Waiting time | Turn around time |");
            Console.WriteLine(string.Concat(Enumerable.Repeat("-", 58)));

            for (int i = 0; i < n; i++)
            {
                total_wt += wt[i];
                total_tat += tat[i];
                Console.WriteLine(String.Format("|{1,5}{0,4}|{2,6}{0,6}|{3,8}{0,6}|{4,10}{0,8}|", "", (i + 1), bt[i], wt[i], tat[i]));
            }
            Console.WriteLine(string.Concat(Enumerable.Repeat("-", 58)));
        }
    }

    class Program
    {
        static void Main()
        {
            int[] processes = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            int n = processes.Length;
            int[] burst_time = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            int[] burst_time1 = { 1, 1, 10, 1, 1, 10, 1, 1, 10, 1 };
            int[] burst_time2 = { 10, 10, 10, 10, 10, 10, 10, 10, 10, 1 };
            int quantum = 3;

            Console.WriteLine("\nTest 1:");
            FCFS.Start_Planning(processes, n, burst_time);
            RR.Start_Planning(processes, n, burst_time, quantum);

            Console.WriteLine("\nTest 2:");
            FCFS.Start_Planning(processes, n, burst_time1);
            RR.Start_Planning(processes, n, burst_time1, quantum);

            Console.WriteLine("\nTest 3:");
            FCFS.Start_Planning(processes, n, burst_time2);
            RR.Start_Planning(processes, n, burst_time2, quantum);

            Console.ReadKey();
        }
    }
}