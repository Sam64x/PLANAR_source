#include <windows.h>
#include <stdio.h>
#include <tchar.h>
#include <signal.h>
#include <unistd.h>

int _tmain(int argc, TCHAR *argv[])
{
    Sleep(5000);
    printf("Hello!\n");
    kill(getpid(),SIGSEGV);
    return 0;
}
