set_languages("c99", "cxx17")

target("main")
    set_kind("binary")
    add_files("main.c")

target("process")
    set_kind("binary")
    add_files("process.c")
