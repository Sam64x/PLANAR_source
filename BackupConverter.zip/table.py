import tkinter as tk
from tkinter import ttk


def total_length(t):
    length = 0
    for item in t:
        if isinstance(item, tuple):
            length += total_length(item)
        else:
            length += len(str(item))
    return length


def generate_table(window, data_block):
    # Define columns
    columns = ('Key', 'Value')

    tree = ttk.Treeview(window, columns=columns, show='headings')

    # Define headings
    tree.heading('Key', text='Key')
    tree.heading('Value', text='Value', anchor='w')
    tree.column('Key', minwidth=200)
    tree.column('Value', minwidth=1500)

    # Insert values
    for item in data_block:
        tree.insert('', tk.END, values=item)

    scroll_y = ttk.Scrollbar(window, orient='vertical', command=tree.yview)
    scroll_y.grid(row=0, column=1, sticky='ns')
    tree.configure(yscrollcommand=scroll_y.set)

    scroll_x = ttk.Scrollbar(window, orient='horizontal', command=tree.xview)
    scroll_x.grid(row=1, column=0, sticky='we')
    tree.configure(xscrollcommand=scroll_x.set)

    tree.grid(row=0, column=0, sticky='nsew')


def generate_crc_table(window, data_block):
    # define columns
    columns = ('DataBlock', 'DataValidity')

    tree = ttk.Treeview(window, columns=columns, show='headings')

    # define headings
    tree.heading('DataBlock', text='DataBlock')
    tree.heading('DataValidity', text='DataValidity')

    # insert values
    for item in data_block:
        key, value = item
        if value == "valid":
            tree.insert('', tk.END, values=item, tags=('green',))
        else:
            tree.insert('', tk.END, values=item, tags=('red',))

    # configure tag for green rows
    tree.tag_configure('green', background='lightgreen')
    # configure tag for red rows
    tree.tag_configure('red', background='red')

    tree.grid(row=0, column=0, sticky='nsew')
