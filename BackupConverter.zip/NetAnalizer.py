from struct import *
import os

crc_table = [0] * 256
crc_table_empty = True


class NetworkAnalyzer(object):
    def __init__(self, backup):
        self.backup = backup
        self.backup_size = self.backup_size()
        self.backup_data = self.read_backup()
        self.NumSteps = None
        self.DACNumResp = None
        self.PowerTableEnd = None
        self.nFreq = None
        self.CalibrationTermsNumber = None
        self.crcTable = ()
        self.crcTableKeys = ()
        self.ReservedBlock = ()
        self.LinearizationData = ()
        self.IfSwitchingData = ()
        self.NullBlock = ()
        self.RefOscCalibration = ()
        self.LinearizationFrequency = ()
        self.LinearizationFrequency2 = ()
        self.LastVerification = ()
        self.TPowerTableHeader = ()
        self.DACSteps = ()
        self.TPowerTable = ()
        self.TPowerTableCRC = ()
        self.TRcvResponseHeader = ()
        self.TRcvSensHeader = ()
        self.CalibrationTerms = ()
        self.CalibrationTermsCRC = ()
        self.HighSensCorr = ()
        self.HighSensCorrCRC = ()

    @staticmethod
    def get_value(tmp_key, tmp_list):  # Получить значения кортежа по ключу
        for key_i, value in tmp_list:
            if tmp_key == key_i:
                return value[0]

    @staticmethod
    def make_crc_table():
        global crc_table_empty, crc_table
        if not crc_table_empty:
            return
        poly = 0xEDB88320
        for i in range(256):
            c = i
            for j in range(8):
                if c & 1:
                    c = poly ^ (c >> 1)
                else:
                    c >>= 1
            crc_table[i] = c
        crc_table_empty = False

    @staticmethod
    def CRC32(crc, buf):
        global crc_table_empty, crc_table
        if buf is None:
            return 0
        if crc_table_empty:
            NetworkAnalyzer.make_crc_table()
        crc = crc ^ 0xFFFFFFFF
        for b in buf:
            crc = crc_table[(crc ^ b) & 0xFF] ^ (crc >> 8)
        return crc ^ 0xFFFFFFFF

    def check_crc(self, dataStart, dataEnd):
        dataSize = dataEnd - dataStart
        buf = unpack_from("{}B".format(dataSize), self.backup_data, offset=dataStart)
        crc_from_backup = unpack_from("L", self.backup_data, offset=dataEnd)
        # print("CRC from backup: ", crc_from_backup[0])
        # print("CRC exact:", NetworkAnalyzer.CRC32(0, buf))
        if NetworkAnalyzer.CRC32(0, buf) == crc_from_backup[0]:
            return "valid"
        else:
            return "invalid"

    def fill_backup(self, n):
        self.null_block()
        self.ref_osc_calibration()
        self.linearization_frequency()
        self.linearization_frequency2()
        self.last_verification()
        self.t_power_table_header(n)

        self.DACNumResp = self.get_value("DACNumResp", self.TPowerTableHeader)
        self.dac_steps(n, self.DACNumResp)

        self.NumSteps = self.get_value("NumSteps", self.TPowerTableHeader)
        self.t_power_table(n, self.DACNumResp, self.NumSteps)

        self.PowerTableEnd = self.get_value("PowerTableEnd", self.NullBlock)
        self.trcv_response_header(n, self.PowerTableEnd)

        self.nFreq = 600  # Число точек частотного плана
        Version = self.get_value("Version", self.TRcvResponseHeader)
        if Version == 0:
            self.CalibrationTermsNumber = 3
        else:
            self.CalibrationTermsNumber = 4
        self.calibration_terms(n, self.PowerTableEnd, self.nFreq, self.CalibrationTermsNumber)
        self.trcv_sens_header(n, self.PowerTableEnd, self.nFreq, self.CalibrationTermsNumber)
        self.high_sens_corr(n, self.PowerTableEnd, self.nFreq, self.CalibrationTermsNumber)

        self.if_switching_data(n)
        self.linearization_data(n)
        self.reserved_data()

    def write_backup(self, name, N, M):  # N - количество портов оригинала, M - количество портов преобразования
        crcSize = 4
        PowerTableEnd = self.PowerTableEnd
        # Create Empty Binary File
        with open(name, "wb") as f:
            f.seek(self.backup_size - 1)
            f.write(pack('B', 0))

            # RefOscCalibration:
            readStep = 14
            writeStep = 14
            f.seek(writeStep)
            f.write(self.backup_data[readStep:readStep + 6])

            # LinearizationFrequency:
            readStep = 20
            writeStep = 20
            f.seek(writeStep)
            f.write(self.backup_data[readStep:readStep + 12])

            # LinearizationFrequency2:
            readStep = 32
            writeStep = 32
            f.seek(writeStep)
            f.write(self.backup_data[readStep:readStep + 10])

            # LastVerification:
            readStep = 42
            writeStep = 42
            f.seek(writeStep)
            f.write(self.backup_data[readStep:readStep + 16])

            # TPowerTableHeader:
            readStep = 64
            writeStep = 64
            buf = ()
            f.seek(writeStep)
            f.write(self.backup_data[readStep:readStep + 18])
            buf += unpack('18B', self.backup_data[readStep:readStep + 18])
            readStep += 18
            writeStep += 18
            f.seek(writeStep)
            f.write(self.backup_data[readStep:readStep + M])
            buf += unpack('{}B'.format(M), self.backup_data[readStep:readStep + M])
            readStep += N
            writeStep += M
            f.seek(writeStep)
            f.write(self.backup_data[readStep:readStep + 12 * M])
            buf += unpack('{}B'.format(12 * M), self.backup_data[readStep:readStep + 12 * M])
            readStep += 12 * N
            writeStep += 12 * M
            f.seek(writeStep)
            f.write(self.backup_data[readStep:readStep + 10 * M])
            buf += unpack('{}B'.format(10 * M), self.backup_data[readStep:readStep + 10 * M])
            readStep += 10 * N
            writeStep += 10 * M
            f.seek(writeStep)
            f.write(self.backup_data[readStep:readStep + 2 * M])
            buf += unpack('{}B'.format(2 * M), self.backup_data[readStep:readStep + 2 * M])
            readStep += 2 * N
            writeStep += 2 * M
            crc = NetworkAnalyzer.CRC32(0, buf)
            f.seek(writeStep)
            f.write(pack('L', crc))

            # DACSteps
            readStep = 25 * N + 86
            writeStep = 25 * M + 86
            buf = ()
            f.seek(writeStep)
            f.write(self.backup_data[readStep:readStep + self.DACNumResp * 2])
            buf += unpack('{}B'.format(self.DACNumResp * 2), self.backup_data[readStep:readStep + self.DACNumResp * 2])
            writeStep += 2 * self.DACNumResp
            readStep += 2 * self.DACNumResp
            crc = NetworkAnalyzer.CRC32(0, buf)
            f.seek(writeStep)
            f.write(pack('L', crc))

            # TPowerTable
            readStep = 25 * N + 90 + 2 * self.DACNumResp
            writeStep = 25 * M + 90 + 2 * self.DACNumResp
            lenStep = 602 * 2
            for m in range(M):
                # DACX01, DACX02, DACX1, DACX2
                buf = ()
                f.seek(writeStep)
                f.write(self.backup_data[readStep:readStep + 8])
                buf += unpack('{}B'.format(8), self.backup_data[readStep:readStep + 8])
                readStep += 8
                writeStep += 8
                crc = NetworkAnalyzer.CRC32(0, buf)
                f.seek(writeStep)
                f.write(pack('L', crc))
                readStep += 4
                writeStep += 4
                # Step_1...Step_K, K = NumSteps
                for i in range(self.NumSteps):
                    buf = ()
                    f.seek(writeStep)
                    f.write(self.backup_data[readStep:readStep + lenStep])
                    buf += unpack('{}B'.format(lenStep), self.backup_data[readStep:readStep + lenStep])
                    readStep += lenStep
                    writeStep += lenStep
                    crc = NetworkAnalyzer.CRC32(0, buf)
                    f.seek(writeStep)
                    f.write(pack('L', crc))
                    readStep += 4
                    writeStep += 4

                # DAC1_1...DAC1_K, K = DACNumResp
                for i in range(self.DACNumResp):
                    buf = ()
                    f.seek(writeStep)
                    f.write(self.backup_data[readStep:readStep + lenStep])
                    buf += unpack('{}B'.format(lenStep), self.backup_data[readStep:readStep + lenStep])
                    readStep += lenStep
                    writeStep += lenStep
                    crc = NetworkAnalyzer.CRC32(0, buf)
                    f.seek(writeStep)
                    f.write(pack('L', crc))
                    readStep += 4
                    writeStep += 4

                # DAC2_1...DAC2_K, K = DACNumResp
                for i in range(self.DACNumResp):
                    buf = ()
                    f.seek(writeStep)
                    f.write(self.backup_data[readStep:readStep + lenStep])
                    buf += unpack('{}B'.format(lenStep), self.backup_data[readStep:readStep + lenStep])
                    readStep += lenStep
                    writeStep += lenStep
                    crc = NetworkAnalyzer.CRC32(0, buf)
                    f.seek(writeStep)
                    f.write(pack('L', crc))
                    readStep += 4
                    writeStep += 4

                # RCorr
                buf = ()
                f.seek(writeStep)
                f.write(self.backup_data[readStep:readStep + lenStep])
                buf += unpack('{}B'.format(lenStep), self.backup_data[readStep:readStep + lenStep])
                readStep += lenStep
                writeStep += lenStep
                crc = NetworkAnalyzer.CRC32(0, buf)
                f.seek(writeStep)
                f.write(pack('L', crc))
                readStep += 4
                writeStep += 4

                # DAC3_1...DAC3_K, K = DACNumResp
                for i in range(self.DACNumResp):
                    buf = ()
                    f.seek(writeStep)
                    f.write(self.backup_data[readStep:readStep + lenStep])
                    buf += unpack('{}B'.format(lenStep), self.backup_data[readStep:readStep + lenStep])
                    readStep += lenStep
                    writeStep += lenStep
                    crc = NetworkAnalyzer.CRC32(0, buf)
                    f.seek(writeStep)
                    f.write(pack('L', crc))
                    readStep += 4
                    writeStep += 4

            PowerTableEndW = writeStep

            # NullBlock:
            readStep = 0
            writeStep = 0
            buf = ()
            f.seek(writeStep)
            f.write(self.backup_data[readStep:readStep+4])
            buf += unpack('4B', self.backup_data[readStep:readStep+4])
            readStep += 4
            writeStep += 4
            f.seek(writeStep)
            f.write(pack('L', PowerTableEndW))
            tmp = pack('L', PowerTableEndW)
            buf += unpack('4B', tmp)
            readStep += 4
            writeStep += 4
            crc = NetworkAnalyzer.CRC32(0, buf)
            f.seek(writeStep)
            f.write(pack('L', crc))

            # TRcvResponseHeader
            readStep = PowerTableEnd
            writeStep = PowerTableEndW
            buf = ()
            f.seek(writeStep)
            f.write(self.backup_data[readStep:readStep + 8])
            buf += unpack('8B', self.backup_data[readStep:readStep + 8])
            readStep += 8
            writeStep += 8
            f.seek(writeStep)
            f.write(self.backup_data[readStep:readStep + M])
            buf += unpack('{}B'.format(M), self.backup_data[readStep:readStep + M])
            readStep += N
            writeStep += M
            f.seek(writeStep)
            f.write(self.backup_data[readStep:readStep + 12 * M])
            buf += unpack('{}B'.format(12 * M), self.backup_data[readStep:readStep + 12 * M])
            readStep += 12 * N
            writeStep += 12 * M
            f.seek(writeStep)
            f.write(self.backup_data[readStep:readStep + 10 * M])
            buf += unpack('{}B'.format(10 * M), self.backup_data[readStep:readStep + 10 * M])
            readStep += 10 * N
            writeStep += 10 * M
            f.seek(writeStep)
            f.write(self.backup_data[readStep:readStep + 2 * M])
            buf += unpack('{}B'.format(2 * M), self.backup_data[readStep:readStep + 2 * M])
            readStep += 2 * N
            writeStep += 2 * M
            crc = NetworkAnalyzer.CRC32(0, buf)
            f.seek(writeStep)
            f.write(pack('L', crc))

            # CalibrationTerms
            TRcvResponseHeaderSize = 25 * N + 8 + crcSize
            TRcvResponseHeaderSizeW = 25 * M + 8 + crcSize
            readStep = PowerTableEnd + TRcvResponseHeaderSize
            writeStep = PowerTableEndW + TRcvResponseHeaderSizeW
            termsSize = 8 * self.nFreq * self.CalibrationTermsNumber
            CalibrationTermsSize = (termsSize + crcSize) * N
            CalibrationTermsSizeW = (termsSize + crcSize) * M
            for m in range(M):
                buf = ()
                f.seek(writeStep)
                f.write(self.backup_data[readStep:readStep + termsSize])
                buf += unpack('{}B'.format(termsSize), self.backup_data[readStep:readStep + termsSize])
                readStep += termsSize
                writeStep += termsSize
                crc = NetworkAnalyzer.CRC32(0, buf)
                f.seek(writeStep)
                f.write(pack('L', crc))
                readStep += 4
                writeStep += 4

            # TRcvSensHeader
            readStep = PowerTableEnd + TRcvResponseHeaderSize + CalibrationTermsSize
            writeStep = PowerTableEndW + TRcvResponseHeaderSizeW + CalibrationTermsSizeW
            buf = ()
            TRcvSensHeaderSize = 26 + crcSize
            TRcvSensHeaderSizeW = 26 + crcSize
            f.seek(writeStep)
            f.write(self.backup_data[readStep:readStep+26])
            buf += unpack('{}B'.format(26), self.backup_data[readStep:readStep+26])
            readStep += 26
            writeStep += 26
            crc = NetworkAnalyzer.CRC32(0, buf)
            f.seek(writeStep)
            f.write(pack('L', crc))

            # HighSensCorr
            readStep = PowerTableEnd + TRcvResponseHeaderSize + CalibrationTermsSize + TRcvSensHeaderSize
            writeStep = PowerTableEndW + TRcvResponseHeaderSizeW + CalibrationTermsSizeW + TRcvSensHeaderSizeW
            sensSize = 4 * self.nFreq * 4
            for m in range(M):
                buf = ()
                f.seek(writeStep)
                f.write(self.backup_data[readStep:readStep + sensSize])
                buf += unpack('{}B'.format(sensSize), self.backup_data[readStep:readStep + sensSize])
                readStep += sensSize
                writeStep += sensSize
                crc = NetworkAnalyzer.CRC32(0, buf)
                f.seek(writeStep)
                f.write(pack('L', crc))
                readStep += 4
                writeStep += 4

            # IFSwitchingData
            writeStep = self.backup_size - 2048 - 1024 * M * 2
            for i in range(2 * M, 2 * M + 4):
                f.seek(writeStep)
                f.write(self.backup_data[self.backup_size-1024*(i+1):self.backup_size-1024*(i+1)+256])

            # LinearizationData
            writeStep = self.backup_size - 2048 - 1024 * M * 2
            for i in range(2 * M):
                f.seek(writeStep)
                f.write(self.backup_data[self.backup_size-1024 * (i + 1):self.backup_size - 1024 * (i + 1) + 1024])

            # ReservedData
            writeStep = self.backup_size - 64
            f.seek(writeStep)
            f.write(self.backup_data[self.backup_size-64:self.backup_size-46])

    def backup_size(self):  # Размер бэкапа в байтах
        return os.path.getsize(self.backup)

    def read_backup(self):  # Чтение бэкапа 8-го портового векторного анализатора цепей
        with open(self.backup, 'rb') as bkup:
            backup_data = bkup.read()
        return backup_data

    def null_block(self):  # Нулевой блок
        readStep = 0

        dataStart = readStep
        Marker = unpack_from("H", self.backup_data, offset=readStep)
        readStep += 2
        Reserve = unpack_from("H", self.backup_data, offset=readStep)
        readStep += 2
        PowerTableEnd = unpack_from("L", self.backup_data, offset=readStep)
        readStep += 4
        dataEnd = readStep

        self.crcTableKeys += "NullBlockCRC",
        self.crcTable += self.check_crc(dataStart, dataEnd),

        null_block_keys = ("Marker", "Reserve", "PowerTableEnd")
        self.NullBlock += Marker, Reserve, PowerTableEnd
        self.NullBlock = tuple(zip(null_block_keys, self.NullBlock))

    def ref_osc_calibration(self):  # Калибровка опорного генератора
        readStep = 14

        dataStart = readStep
        data = unpack_from("B", self.backup_data, offset=readStep)
        readStep += 1
        reserve = unpack_from("B", self.backup_data, offset=readStep)
        readStep += 1
        dataEnd = readStep

        self.crcTableKeys += "RefOscCalibrationCRC",
        self.crcTable += self.check_crc(dataStart, dataEnd),

        calibration_keys = ("data", "reserve")
        self.RefOscCalibration += data, reserve
        self.RefOscCalibration = tuple(zip(calibration_keys, self.RefOscCalibration))

    def linearization_frequency(self):  # Характерные частоты линеаризации
        readStep = 20

        dataStart = readStep
        f1 = unpack_from("f", self.backup_data, offset=readStep)
        readStep += 4
        f2 = unpack_from("f", self.backup_data, offset=readStep)
        readStep += 4
        dataEnd = readStep

        self.crcTableKeys += "LinearizationFrequencyCRC",
        self.crcTable += self.check_crc(dataStart, dataEnd),

        self.LinearizationFrequency += f1, f2
        self.LinearizationFrequency = tuple(zip(("f1", "f2"), self.LinearizationFrequency))

    def linearization_frequency2(self):  # Характерные частоты линеаризации вер. 2
        readStep = 32

        dataStart = readStep
        self.LinearizationFrequency2 += unpack_from("H", self.backup_data, offset=readStep),
        readStep += 2
        dataEnd = readStep + 4

        self.crcTableKeys += "LinearizationFrequency2CRC",
        self.crcTable += self.check_crc(dataStart, dataEnd),

        self.LinearizationFrequency2 = tuple(zip(("version",), self.LinearizationFrequency2))

    def last_verification(self):  # Дата последней верификации и интервал
        readStep = 42

        dataStart = readStep
        date = unpack_from("10B", self.backup_data, offset=readStep)
        readStep += 10
        interval = unpack_from("H", self.backup_data, offset=readStep)
        readStep += 2
        dataEnd = readStep

        self.crcTableKeys += "LastVerificationCRC",
        self.crcTable += self.check_crc(dataStart, dataEnd),
        self.LastVerification = tuple(zip(("date", "interval"), (date, interval)))

    def t_power_table_header(self, N):  # Заголовок таблицы калибровки мощности
        readStep = 64

        dataStart = readStep
        Version = unpack_from("H", self.backup_data, offset=readStep)  # Версия
        readStep += 2
        FrequencyPlan = unpack_from("H", self.backup_data, offset=readStep)  # Код частотного плана
        readStep += 2
        MaxFrequency = unpack_from("i", self.backup_data, offset=readStep)  # MaxFrequency in MHz
        readStep += 4
        MaxPower = unpack_from("i", self.backup_data, offset=readStep)  # MaxPower in 0.001 dBm
        readStep += 4
        NumSteps = unpack_from("H", self.backup_data, offset=readStep)  # Число ступеней
        readStep += 2
        DACNumResp = unpack_from("H", self.backup_data, offset=readStep)  # Число характеристик ЦАП
        readStep += 2
        DACBegin = unpack_from("H", self.backup_data, offset=readStep)  # Начальный код ЦАП
        readStep += 2
        PortValid = unpack_from("{}?".format(N), self.backup_data, offset=readStep)  # Порт действителен
        readStep += N
        CalDate = ()  # Дата калибровки
        for i in range(12):
            CalDate += unpack_from("{}B".format(N), self.backup_data, offset=readStep),
            readStep += N
        CalTime = ()  # Время калибровки
        for i in range(10):
            CalTime += unpack_from("{}B".format(N), self.backup_data, offset=readStep),
            readStep += N
        CalTemper = unpack_from("{}H".format(N), self.backup_data, offset=readStep)  # Температура калибровки
        readStep += 2 * N
        dataEnd = readStep

        self.crcTableKeys += "TPowerTableHeaderCRC",
        self.crcTable += self.check_crc(dataStart, dataEnd),

        self.TPowerTableHeader += Version, FrequencyPlan, MaxFrequency, MaxPower, NumSteps, \
            DACNumResp, DACBegin, PortValid, CalDate, CalTime, CalTemper,
        t_power_table_header_keys = ("Version", "FrequencyPlan", "MaxFrequency", "MaxPower", "NumSteps",
                                     "DACNumResp", "DACBegin", "PortValid", "CalDate", "CalTime", "CalTemper")
        self.TPowerTableHeader = tuple(zip(t_power_table_header_keys, self.TPowerTableHeader))

    def dac_steps(self, N, DACNumResp):  # Номера измеренных ступеней ЦАП
        readStep = 25 * N + 86

        dataStart = readStep
        DACStepsKeys = ()
        self.DACSteps += unpack_from("{}H".format(DACNumResp), self.backup_data, offset=readStep),
        readStep += DACNumResp * 2
        dataEnd = readStep

        self.crcTableKeys += "DACStepsCRC",
        self.crcTable += self.check_crc(dataStart, dataEnd),

        for i in range(DACNumResp):
            DACStepsKeys += "DACSteps:".format(i + 1),
        self.DACSteps = tuple(zip(DACStepsKeys, self.DACSteps))

    def t_power_table(self, N, DACNumResp, NumSteps):  # Таблица мощности
        validData = True
        TPowerTableCRCKeys = ()
        lenStep = 602 * 2  # 602 * sizeof(USHORT)
        readStep = 25 * N + 90 + 2 * DACNumResp
        crcSize = 4
        TPowerTableKeys = ()

        for n in range(N):
            # DACX01, DACX02, DACX1, DACX2
            dataStart = readStep
            for i in range(4):
                self.TPowerTable += unpack_from("H", self.backup_data, offset=readStep),
                readStep += 2
            dataEnd = readStep

            TPowerTableCRCKeys += "TPowerPortHeaderCRC [{}]".format(n + 1),
            self.TPowerTableCRC += self.check_crc(dataStart, dataEnd),
            TPowerTableKeys += ("DACX01 [{}]".format(n + 1), "DACX02 [{}]".format(n + 1),
                                "DACX1 [{}]".format(n + 1), "DACX2 [{}]".format(n + 1))
            readStep += crcSize

            # Step_1...Step_M, M = NumSteps
            for i in range(NumSteps):
                self.TPowerTable += unpack_from("{}B".format(lenStep), self.backup_data, offset=readStep),

                TPowerTableCRCKeys += "Step_{} [{}]".format(i + 1, n + 1),
                self.TPowerTableCRC += self.check_crc(readStep, readStep + lenStep),

                readStep += lenStep + crcSize
                TPowerTableKeys += "Step_{} [{}]".format(i + 1, n + 1),

            # DAC1_1...DAC1_K, K = DACNumResp = 12
            for i in range(DACNumResp):
                self.TPowerTable += unpack_from("{}B".format(lenStep), self.backup_data, offset=readStep),

                TPowerTableCRCKeys += "DAС1_{} [{}]".format(i + 1, n + 1),
                self.TPowerTableCRC += self.check_crc(readStep, readStep + lenStep),

                readStep += lenStep + crcSize
                TPowerTableKeys += "DAС1_{} [{}]".format(i + 1, n + 1),

            # DAC2_1...DAC2_K, K = DACNumResp = 12
            for i in range(DACNumResp):
                self.TPowerTable += unpack_from("{}B".format(lenStep), self.backup_data, offset=readStep),

                TPowerTableCRCKeys += "DAС2_{} [{}]".format(i + 1, n + 1),
                self.TPowerTableCRC += self.check_crc(readStep, readStep + lenStep),

                readStep += lenStep + crcSize
                TPowerTableKeys += "DAС2_{} [{}]".format(i + 1, n + 1),

            # RCorr
            self.TPowerTable += unpack_from("{}B".format(lenStep), self.backup_data, offset=readStep),

            TPowerTableCRCKeys += "RCorr [{}]".format(n + 1),
            self.TPowerTableCRC += self.check_crc(readStep, readStep + lenStep),

            readStep += lenStep + crcSize
            TPowerTableKeys += "cfR",

            # DAC3_1...DAC3_K, K = DACNumResp
            for i in range(DACNumResp):
                self.TPowerTable += unpack_from("{}B".format(lenStep), self.backup_data, offset=readStep),

                TPowerTableCRCKeys += "DAС3_{} [{}]".format(i + 1, n + 1),
                self.TPowerTableCRC += self.check_crc(readStep, readStep + lenStep),

                readStep += lenStep + crcSize
                TPowerTableKeys += "DAС3_{} [{}]".format(i + 1, n + 1),

        self.TPowerTable = tuple(zip(TPowerTableKeys, self.TPowerTable))

        self.TPowerTableCRC = tuple(zip(TPowerTableCRCKeys, self.TPowerTableCRC))
        for key, value in self.TPowerTableCRC:
            if value == "invalid":
                validData = False
                break

        self.crcTableKeys += "TPowerTableCRC",
        if validData:
            self.crcTable += "valid",
        else:
            self.crcTable += "invalid",

    def trcv_response_header(self, N, PowerTableEnd):  # Таблица частотного отклика приемников
        readStep = PowerTableEnd

        dataStart = readStep
        Version = unpack_from("H", self.backup_data, offset=readStep)  # Версия (USHORT)
        readStep += 2
        FrequencyPlan = unpack_from("H", self.backup_data, offset=readStep)  # Код частотного плана (USHORT)
        readStep += 2
        MaxFrequency = unpack_from("i", self.backup_data, offset=readStep)  # MaxFrequency in MHz (int)
        readStep += 4
        PortValid = unpack_from("{}?".format(N), self.backup_data, offset=readStep)  # Приемник калиброван (bool)
        readStep += N
        CalDate = ()  # Дата калибровки
        for i in range(12):
            CalDate += unpack_from("{}B".format(N), self.backup_data, offset=readStep),
            readStep += N
        CalTime = ()  # Время калибровки
        for i in range(10):
            CalTime += unpack_from("{}B".format(N), self.backup_data, offset=readStep),
            readStep += N
        CalTemper = unpack_from("{}H".format(N), self.backup_data, offset=readStep)  # Температура калибровки
        readStep += 2 * N
        dataEnd = readStep

        self.crcTableKeys += "TRcvResponseHeaderCRC",
        self.crcTable += self.check_crc(dataStart, dataEnd),

        self.TRcvResponseHeader += Version, FrequencyPlan, MaxFrequency, PortValid, CalDate, CalTime, CalTemper,
        trcv_response_header_keys = ("Version", "FrequencyPlan", "MaxFrequency",
                                     "PortValid", "CalDate", "CalTime", "CalTemper")
        self.TRcvResponseHeader = tuple(zip(trcv_response_header_keys, self.TRcvResponseHeader))

    def calibration_terms(self, n, PowerTableEnd, nFreq, CalibrationTermsNumber):  # Термы 2-ух портовой калибровки
        validData = True
        CalibrationTermsCRCKeys = ()
        calibration_terms_keys = ()
        crcSize = 4
        TRcvResponseHeaderSize = 25 * n + 8 + crcSize
        readStep = PowerTableEnd + TRcvResponseHeaderSize
        termsSize = 8 * nFreq * CalibrationTermsNumber  # sizeof(complex<float>) = 8

        for i in range(n):
            Terms = unpack_from("{}B".format(termsSize), self.backup_data, offset=readStep),

            CalibrationTermsCRCKeys += "CalibrationTermsCRC [{}]".format(i + 1),
            self.CalibrationTermsCRC += self.check_crc(readStep, readStep + termsSize),

            readStep += termsSize + crcSize

            calibration_terms_keys += "CalibrationTerms [{}]".format(i + 1),
            self.CalibrationTerms += Terms,

        self.CalibrationTerms = tuple(zip(calibration_terms_keys, self.CalibrationTerms))
        self.CalibrationTermsCRC = tuple(zip(CalibrationTermsCRCKeys, self.CalibrationTermsCRC))
        for key, value in self.CalibrationTermsCRC:
            if value == "invalid":
                validData = False
                break

        self.crcTableKeys += "CalibrationTermsCRC",
        if validData:
            self.crcTable += "valid",
        else:
            self.crcTable += "invalid",

    def trcv_sens_header(self, n, PowerTableEnd, nFreq,
                         CalibrationTermsNumber):  # Табл. частотного отклика приемников выс. чувств.
        crcSize = 4
        termsSize = 8 * nFreq * CalibrationTermsNumber  # sizeof(complex<float>) * nFreq * calibrationTermsNumber

        CalibrationTermsSize = (termsSize + crcSize) * n
        TRcvResponseHeaderSize = 25 * n + 8 + crcSize
        readStep = CalibrationTermsSize + TRcvResponseHeaderSize + PowerTableEnd

        dataStart = readStep
        Version = unpack_from("H", self.backup_data, offset=readStep)  # Версия
        readStep += 2
        CalDate = unpack_from("12B", self.backup_data, offset=readStep)
        readStep += 12
        CalTime = unpack_from("10B", self.backup_data, offset=readStep)
        readStep += 10
        CalTemper = unpack_from("H", self.backup_data, offset=readStep)  # Температура калибровки
        readStep += 2
        dataEnd = readStep

        self.crcTableKeys += "TRcvSensHeaderCRC",
        self.crcTable += self.check_crc(dataStart, dataEnd),

        self.TRcvSensHeader += Version, CalDate, CalTime, CalTemper,
        trcv_sens_header_keys = ("Version", "CalDate", "CalTime", "CalTemper")
        self.TRcvSensHeader = tuple(zip(trcv_sens_header_keys, self.TRcvSensHeader))

    def high_sens_corr(self, N, PowerTableEnd, nFreq, CalibrationTermsNumber):  # Коррекция высокой чувствительности
        validData = True
        HighSensCorrCRCKeys = ()
        high_sens_corr_keys = ()
        crcSize = 4
        termsSize = 8 * nFreq * CalibrationTermsNumber  # sizeof(complex<float>) * nFreq * calibrationTermsNumber

        TRcvSensHeaderSize = 26 + crcSize
        CalibrationTermsSize = (termsSize + crcSize) * N
        TRcvResponseHeaderSize = 25 * N + 8 + crcSize
        readStep = TRcvSensHeaderSize + CalibrationTermsSize + TRcvResponseHeaderSize + PowerTableEnd

        sensSize = 4 * nFreq * 4  # sizeof(float) * nFreq * 4
        for i in range(N):
            self.HighSensCorr += unpack_from("{}B".format(sensSize), self.backup_data, offset=readStep),

            HighSensCorrCRCKeys += "HighSensCorrCRC [{}]".format(i + 1),
            self.HighSensCorrCRC += self.check_crc(readStep, readStep + sensSize),

            readStep += sensSize + crcSize
            high_sens_corr_keys += "HighSensCorr [{}]".format(i + 1),

        self.HighSensCorr = tuple(zip(high_sens_corr_keys, self.HighSensCorr))

        self.HighSensCorrCRC = tuple(zip(HighSensCorrCRCKeys, self.HighSensCorrCRC))
        for key, value in self.CalibrationTermsCRC:
            if value == "invalid":
                validData = False
                break

        self.crcTableKeys += "HighSensCorrCRC",
        if validData:
            self.crcTable += "valid",
        else:
            self.crcTable += "invalid",

        self.crcTable = tuple(zip(self.crcTableKeys, self.crcTable))

    def if_switching_data(self, N):  # IF switching data (N - число портов)
        for i in range(2 * N, 2 * N + 4):
            self.IfSwitchingData += unpack_from("256B", self.backup_data, offset=self.backup_size - 1024 * (i + 1)),
        tr_keys = ("r2_port", "t2_port", "r1_port", "t1_port")
        self.IfSwitchingData = tuple(zip(tr_keys, self.IfSwitchingData))

    def linearization_data(self, N):  # Linearization data (N - число портов)
        for i in range(2 * N):
            self.LinearizationData += unpack_from("1024B", self.backup_data, offset=self.backup_size - 1024 * (i + 1)),
        rcv_keys = ()
        for i in range(N):
            rcv_keys += "rrcv_port{}".format(i + 1),
            rcv_keys += "trcv_port{}".format(i + 1),
        self.LinearizationData = tuple(zip(rcv_keys, self.LinearizationData))

    def reserved_data(self):  # Reserved Data
        Marker = unpack_from("L", self.backup_data, offset=self.backup_size - 64)
        VID = unpack_from("H", self.backup_data, offset=self.backup_size - 60)
        PID = unpack_from("H", self.backup_data, offset=self.backup_size - 58)
        Serial = unpack_from("Q", self.backup_data, offset=self.backup_size - 56)
        DID = unpack_from("H", self.backup_data, offset=self.backup_size - 48)
        reserved_keys = ("Marker", "VID", "PID", "Serial", "DID")
        self.ReservedBlock += Marker, VID, PID, Serial, DID
        self.ReservedBlock = tuple(zip(reserved_keys, self.ReservedBlock))


def main():
    backup = "8PortData.bin"
    N = 8
    net_analyzer = NetworkAnalyzer(backup)
    net_analyzer.fill_backup(N)



if __name__ == "__main__":
    main()
