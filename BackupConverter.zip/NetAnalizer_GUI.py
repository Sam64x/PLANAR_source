import math
from tkinter import *
from tkinter import ttk, filedialog
from NetAnalizer import NetworkAnalyzer
from table import generate_table, generate_crc_table

backup_path = None


def open_table(data_block):
    table_window = Toplevel()
    table_window.title('Блок данных')
    generate_table(table_window, data_block)


def open_crc_table(data_block):
    table_window = Toplevel()
    table_window.title('Валидность данных')
    generate_crc_table(table_window, data_block)


def transform_button(transform_window, name, n, m, net_analyzer):
    net_analyzer.write_backup(name, n, m)
    label_13 = Label(transform_window, width=30, text="Бэкап был успешно преобразован", bg='lightgreen')
    label_13.place(x=50, y=200)


def transform_backup(n, net_analyzer):
    tw = Toplevel()
    tw.title('Преобразование {} портового бэкапа'.format(n))
    tw.geometry("800x300")
    tw.resizable(False, False)
    tw.configure(bg='#01796f')
    ttk.Style(tw).theme_use('clam')

    name = Entry(tw)
    m = ttk.Combobox(tw, width=25)
    port_numbers2 = ()
    i = 1
    while math.pow(2, i) < n:
        port_numbers2 += int(math.pow(2, i)),
        i += 1
    m['values'] = port_numbers2
    m['state'] = 'readonly'

    label_13 = Label(tw, width=30, text="Введите имя бэкапа:")
    label_23 = Label(tw, width=30, text="Выберите количество портов бэкапа:")

    label_13.place(x=50, y=50)
    name.place(x=300, y=50)

    label_23.place(x=50, y=100)
    m.place(x=300, y=100)

    btn3 = Button(tw, command=lambda: transform_button(tw, name.get(), n, int(m.get()), net_analyzer))
    btn3.configure(text='Потвердить', width=15)
    btn3.place(x=50, y=150)


def open_backup_data(backup, n):
    net_analyzer = NetworkAnalyzer(backup)
    net_analyzer.fill_backup(n)
    data_window = Toplevel()
    data_window.title('Бэкап {} портового анализатора векторных цепей'.format(n))
    data_window.geometry('1000x800')
    data_window.resizable(False, False)
    data_window.configure(bg='#01796f')
    ttk.Style(data_window).theme_use('clam')

    # Button Nums = 15
    btn2 = Button(data_window, command=lambda: open_table(net_analyzer.NullBlock))
    btn2.configure(bg='lightblue', text="Нулевой блок\n(NullBlock)", height=3, width=30)
    btn2.place(x=100, y=50)

    btn2 = Button(data_window, command=lambda: open_table(net_analyzer.RefOscCalibration))
    btn2.configure(bg='lightblue', text="Калибровка опорного генератора\n(RefOscCalibration)", height=3, width=30)
    btn2.place(x=100, y=150)

    btn2 = Button(data_window, command=lambda: open_table(net_analyzer.LinearizationFrequency))
    btn2.configure(bg='lightblue', text="Хар. частоты линеаризации\n(LinearizationFrequency)", height=3, width=30)
    btn2.place(x=100, y=250)

    btn2 = Button(data_window, command=lambda: open_table(net_analyzer.LinearizationFrequency2))
    btn2.configure(bg='lightblue', text="Хар. частоты линеаризации вер. 2\n(LinearizationFrequency2)", height=3, width=30)
    btn2.place(x=100, y=350)

    btn2 = Button(data_window, bg='lightblue', text="Дата последней вериф. и интервал \n(LastVerification)", height=3,
                  width=30,
                  command=lambda: open_table(net_analyzer.LastVerification))
    btn2.place(x=100, y=450)

    btn2 = Button(data_window, bg='lightblue', text="Заголовок таблицы мощности \n(TPowerTableHeader)", height=3,
                  width=30,
                  command=lambda: open_table(net_analyzer.TPowerTableHeader))
    btn2.place(x=400, y=50)

    btn2 = Button(data_window, bg='lightblue', text="Номера измеренных ступеней ЦАП \n(DACSteps)", height=3, width=30,
                  command=lambda: open_table(net_analyzer.DACSteps))
    btn2.place(x=400, y=150)

    btn2 = Button(data_window, bg='lightblue', text="Таблица мощности \n(TPowerTable):", height=3, width=30,
                  command=lambda: open_table(net_analyzer.TPowerTable))
    btn2.place(x=400, y=250)

    btn2 = Button(data_window, bg='lightblue', text="Заголовок калибровки портов \n(TRcvResponseHeader)", height=3,
                  width=30,
                  command=lambda: open_table(net_analyzer.TRcvResponseHeader))
    btn2.place(x=400, y=350)

    btn2 = Button(data_window, bg='lightblue', text="Термы 2-ух портовой калибровки \n(CalibrationTerms)", height=3,
                  width=30,
                  command=lambda: open_table(net_analyzer.CalibrationTerms))
    btn2.place(x=400, y=450)

    btn2 = Button(data_window, bg='lightblue',
                  text="Заголовок калибровки портов \nвыс. чувствительности \n(TRcvSensHeader)",
                  height=3, width=30,
                  command=lambda: open_table(net_analyzer.TRcvSensHeader))
    btn2.place(x=700, y=50)

    btn2 = Button(data_window, bg='lightblue', text="Корр. высокой чувствительности \n(HighSensCorr)", height=3,
                  width=30,
                  command=lambda: open_table(net_analyzer.HighSensCorr))
    btn2.place(x=700, y=150)

    btn2 = Button(data_window, bg='lightblue', text="IF switching data:", height=3, width=30,
                  command=lambda: open_table(net_analyzer.IfSwitchingData))
    btn2.place(x=700, y=250)

    btn2 = Button(data_window, bg='lightblue', text="Данные линеаризации \n(LinearizationData)", height=3, width=30,
                  command=lambda: open_table(net_analyzer.LinearizationData))
    btn2.place(x=700, y=350)

    btn2 = Button(data_window, bg='lightblue', text="Зарезервированный блок данных \n(ReservedData)", height=3,
                  width=30,
                  command=lambda: open_table(net_analyzer.ReservedBlock))
    btn2.place(x=700, y=450)

    btn2 = Button(data_window, bg='lightblue', text="Валидность блоков данных \n(crcTable)", height=3, width=30,
                  command=lambda: open_crc_table(net_analyzer.crcTable))
    btn2.place(x=400, y=600)

    if n > 2:
        btn2 = Button(data_window, bg='lightblue', text="Преобразовать бэкап", height=3, width=30,
                      command=lambda: transform_backup(n, net_analyzer))
        btn2.place(x=100, y=600)
    else:
        label_12 = Label(data_window, bg='lightblue', text="Преобразовать 2-ух портовый \nбэкап нельзя")
        label_12.configure(height=3, width=30)
        label_12.place(x=100, y=600)


def open_backup():
    global backup_path
    backup_path = filedialog.askopenfilename()
    backup_label.configure(text="Выбран бэкап: {}".format(backup_path), bg='lightgreen')


main_window = Tk()
main_window.title("Выбор бэкапа")
main_window.geometry("800x300")
main_window.resizable(False, False)
main_window.configure(bg='#01796f')
ttk.Style(main_window).theme_use('clam')

name_field = Button(main_window, text="Выбрать файл (*.bin)", width=20, command=lambda: open_backup())
port_number_field = ttk.Combobox(main_window, width=25)
port_numbers = (2, 4, 8)
port_number_field['values'] = port_numbers
port_number_field['state'] = 'readonly'

label_1 = Label(main_window, width=25, text="Загрузите файл бэкапа:")
label_2 = Label(main_window, width=25, text="Количество портов бэкапа:")
backup_label = Label(main_window, text="Выбран бэкап:", bg='lightgreen')

backup_label.place(x=50, y=100)

label_1.place(x=50, y=50)
name_field.place(x=300, y=50)

label_2.place(x=50, y=150)
port_number_field.place(x=300, y=150)

btn = Button(main_window, command=lambda: open_backup_data(backup_path, int(port_number_field.get())))
btn.configure(text="Потвердить", width=15)
btn.place(x=50, y=225)

main_window.mainloop()
